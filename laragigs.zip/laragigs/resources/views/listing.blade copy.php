@extends('layout')
@section('content')

<h1> {{$heading}}</h1> {{-- same as <?php //echo $headings; ?> --}}

{{-- @if (count($listings)==0)
<b>No Listing Available!</b>    
@endif --}}

        <h3>  {{$listings['title'] }}</h3>
        <h5>  {{$listings['description']}} </h5>

@endsection