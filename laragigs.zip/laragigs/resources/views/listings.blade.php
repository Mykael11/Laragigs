@extends('layout')
@section('content')

<h1> {{$headings}}</h1> {{-- same as <?php //echo $headings; ?> --}}

@if (count($listings)==0)
<b>No Listing Available!</b>    
@endif
<ul>
    @foreach($listings as $listing) {{-- @directives --}}
    <a href="/listings/{{$listing['id']}}">
        <li>
            <h3>  {{$listing['title'] }}</h3>
            <h5>  {{$listing['description']}} </h5>
        </li>
    </a>
    @endforeach
</ul>

@endsection