<?php $__env->startSection('content'); ?>

<h1> <?php echo e($heading); ?></h1> 



        <h3>  <?php echo e($listings['title']); ?></h3>
        <h5>  <?php echo e($listings['description']); ?> </h5>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laragigs\resources\views/listing.blade.php ENDPATH**/ ?>