<?php $__env->startSection('content'); ?>

<h1> <?php echo e($headings); ?></h1> 

<?php if(count($listings)==0): ?>
<b>No Listing Available!</b>    
<?php endif; ?>
<ul>
    <?php $__currentLoopData = $listings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <a href="/listings/<?php echo e($listing['id']); ?>">
        <li>
            <h3>  <?php echo e($listing['title']); ?></h3>
            <h5>  <?php echo e($listing['description']); ?> </h5>
        </li>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laragigs\resources\views/listings.blade.php ENDPATH**/ ?>