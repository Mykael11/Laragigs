<?php

use App\Models\Listing;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('listings',[
        'headings'=> 'Latest Listings',
        'listings'=>Listing::all() //also existing in the build in model 
        // 'listings'=>[
        //     [
        //         'id'=>1,
        //         'title'=> 'Listing One',
        //         'description' => 'Making Laravel Application From ground up'
        //     ],
        //     [
        //         'id'=>2,
        //         'title'=> 'Listing Two',
        //         'description' => 'Some random text in a 3d array'
        //     ]
        // ]
        ]
    );
});

// single listing
Route::get('/listings/{id}', function ($id) {
    return view('listing',[
        'heading'=> 'Single Listing',
        'listings'=>Listing::find($id) // from the method defined on models/listing.php and built in
        ]
    );
});



// Route::get('/hello', function () {
//     return response('<h1>Hello World</h1>') // defaul 200 use , code to change
//         ->header('Content-Type','text/plain')
//             ->header('foo','bar'); // custom header
// });

// Route::get('/posts/{id}', function ($id) { //{wildcard} must b same as function args
//     return response('welcome-'. $id);
// })->where('id','[0-9]+'); //constraint + regex

// // dd() die dump print and exit ddd- die dump debug show add. info

// Route::get('/search', function (Request $req) { // Request returns an object with request info
//     //http://127.0.0.1:8000/search?name=test&value=25
//     dd($req->name); // or the $req obj for the whole 
// });