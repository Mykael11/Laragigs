<?php
    namespace App\Models; // must inlcude

use PhpParser\Builder\Class_;

    Class Listing{
        public static function all(){
            return [
                [
                    'id'=>1,
                    'title'=> 'Listing One',
                    'description' => 'Making Laravel Application From ground up'
                ],
                [
                    'id'=>2,
                    'title'=> 'Listing Two',
                    'description' => 'Some random text From The MODEL'
                ]
            ];
        }

        public static function find($id){
            $listings = self::all(); // self referce to the class , calls neighbor

            foreach($listings as $listing){
                if($listing['id'] == $id){
                    return $listing;
                }
            }
        }
    }